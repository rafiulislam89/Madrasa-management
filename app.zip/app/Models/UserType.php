<?php

namespace App\Models;

use Eloquent;

class UserType extends Eloquent
{
    //
}
