<div class="tab-pane fade show active" id="manage-ts">
        {{--Add Time Slots--}}
    @include('pages.support_team.timetables.time_slots.add')
    {{--Manage Time Slots--}}
    @include('pages.support_team.timetables.time_slots.manage')
</div>
